const sr = ScrollReveal({ reset:true});
ScrollReveal({ distance: '0.5em', origin: 'top', duration : 3000})

sr.reveal('#noticias', {duration : 2500})
sr.reveal('#doacoes', {duration : 2500})